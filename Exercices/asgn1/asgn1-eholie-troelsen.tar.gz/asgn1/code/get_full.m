function [P, M] = get_full(T, Rx, Ry, Rz, V)
%% creates a full camera matrix P and a model matrix M

    P = [];
    M = [];
    
%    YOUR CODE GOES HERE
    P = V*T*Rx*Ry*Rz;
end
