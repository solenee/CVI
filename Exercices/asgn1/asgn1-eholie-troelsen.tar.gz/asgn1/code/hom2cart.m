function cartesian_points = hom2cart(homogeneous_points)
%% converts points from homogeneous coordinates to cartesian 3d 

    cartesian_points = [];
    
%   YOUR CODE GOES HERE
    n = size(homogeneous_points);
    %cartesian_points
end
