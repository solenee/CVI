function camera_points = invert_projection(A, projected_points, z)
%% inverts a projection

    camera_points = [];
    
%   YOUR CODE GOES HERE

end