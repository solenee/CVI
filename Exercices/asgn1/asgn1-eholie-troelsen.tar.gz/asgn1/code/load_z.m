function z = load_z(filename)
%% loads z coordinates from file

    z = [];
    
%   YOUR CODE GOES HERE
   
end