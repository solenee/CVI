function edges2 = nonmaxsupp(edges, imgx, imgy)
%% non-maximum suppression

    edges2 = [];
    
%   YOUR CODE GOES HERE


end